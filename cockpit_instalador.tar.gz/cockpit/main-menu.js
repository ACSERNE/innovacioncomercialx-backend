const inquirer = require('inquirer');
const fs = require('fs');
const path = require('path');
const verInventario = require('./inventario');
const generarReporteInventario = require('./reporte-inventario');

async function registrarAccion(email, role, accion) {
  const logPath = path.resolve('./cockpit/logs/actions-log.csv');
  const timestamp = new Date().toISOString();
  const line = `${timestamp},${email},${role},"${accion}"\n`;
  const dir = path.dirname(logPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(logPath)) {
    fs.writeFileSync(logPath, 'timestamp,email,role,action\n');
  }
  fs.appendFileSync(logPath, line);
}

async function mainMenu(usuario) {
  console.log('\n👋 Bienvenido al sistema cockpitizado de Innovación ComercialX');
  console.log('✅ Exportado a cockpit/dashboard.md\n');

  const secciones = await inquirer.prompt([
    {
      type: 'list',
      name: 'grupo',
      message: '📋 Menú principal — Elige una sección:',
      choices: [
        '1) Gestión de usuarios 🧑‍💻',
        '2) Gestión de productos 📦',
        '3) Herramientas del sistema ⚙️',
        '4) Auditoría y reportes 📊',
        '5) Salir 🚪'
      ]
    }
  ]);

  switch (secciones.grupo.split(')')[0].trim()) {
    case '1':
      const usuarioOpc = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcion',
          message: '👤 Opciones de usuario:',
          choices: [
            '1) Crear nuevo usuario',
            '2) Iniciar sesión',
            '3) Asignar rol',
            '4) Volver al menú principal'
          ]
        }
      ]);
      await registrarAccion(usuario.email, usuario.rol, usuarioOpc.opcion);
      break;

    case '2':
      const producto = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcion',
          message: '📦 Opciones de producto:',
          choices: [
            '1) Crear nuevo producto',
            '2) Publicar producto existente',
            '3) ✏️ Editar producto existente',
            '4) ❌ Eliminar producto',
            '5) Ver inventario',
            '6) Exportar inventario',
            '7) Volver al menú principal'
          ]
        }
      ]);
      await registrarAccion(usuario.email, usuario.rol, producto.opcion);
      if (producto.opcion.startsWith('5')) {
        verInventario(usuario.email, usuario.rol);
      } else if (producto.opcion.startsWith('6')) {
        generarReporteInventario(usuario.email, usuario.rol);
      }
      break;

    case '3':
      const sistema = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcion',
          message: '⚙️ Opciones del sistema:',
          choices: [
            '1) Ejecutar diagnóstico',
            '2) Verificar rutas',
            '3) Limpiar carpetas residuales',
            '4) Actualizar README.md',
            '5) Volver al menú principal'
          ]
        }
      ]);
      await registrarAccion(usuario.email, usuario.rol, sistema.opcion);
      break;

    case '4':
      const auditoria = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcion',
          message: '📊 Opciones de auditoría:',
          choices: [
            '1) Ver historial de acciones',
            '2) Generar dashboard CLI',
            '3) Ver flujo de caja',
            '4) Volver al menú principal'
          ]
        }
      ]);
      await registrarAccion(usuario.email, usuario.rol, auditoria.opcion);
      break;

    case '5':
      console.log('\n👋 Sesión finalizada. ¡Hasta pronto!\n');
      await registrarAccion(usuario.email, usuario.rol, 'Salir del sistema');
      break;
  }
}

module.exports = mainMenu;
