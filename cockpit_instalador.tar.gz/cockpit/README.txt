Cockpit CLI - Sistema de validación y menú jerárquico
-----------------------------------------------------
🔐 Validación por correo desde usuarios.csv
📋 Menú adaptativo según rol
🧩 Registro de acciones en logs/acciones.csv
🖼️ Branding visual cockpitizado
