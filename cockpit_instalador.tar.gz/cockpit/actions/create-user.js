module.exports = async () => {
  console.log('⚙️ Acción "create-user" ejecutada (simulada).');
};
