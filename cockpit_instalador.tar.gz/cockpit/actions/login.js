module.exports = async () => {
  console.log('⚙️ Acción "login" ejecutada (simulada).');
};
