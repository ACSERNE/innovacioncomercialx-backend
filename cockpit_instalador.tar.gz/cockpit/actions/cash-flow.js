module.exports = async () => {
  console.log('\n💰 Flujo de caja (simulado):');
  console.log('- Ventas hoy: $1,250');
  console.log('- Compras: $300');
  console.log('- Gastos operativos: $150');
  console.log('- Balance neto: $800');
};
