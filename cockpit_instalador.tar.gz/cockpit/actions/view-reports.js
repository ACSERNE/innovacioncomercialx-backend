module.exports = async () => {
  console.log('⚙️ Acción "view-reports" ejecutada (simulada).');
};
