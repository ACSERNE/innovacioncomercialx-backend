const fs = require('fs');
const path = require('path');

function mostrarDashboard(emailActual) {
  const logPath = path.resolve('./cockpit/logs/actions-log.csv');
  const exportPath = path.resolve('./cockpit/dashboard.md');

  if (!fs.existsSync(logPath)) return;

  const raw = fs.readFileSync(logPath, 'utf8').trim().split('\n').slice(1);
  const registros = raw
    .map(line => {
      const parts = line.split(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/);
      if (parts.length < 4) return null;
      const [timestamp, email, role, action] = parts;
      return {
        timestamp: timestamp.trim(),
        email: email.trim(),
        role: role.trim(),
        action: action ? action.replace(/(^"|"$)/g, '').trim() : '[Sin acción]'
      };
    })
    .filter(r => r && r.email === emailActual);

  const markdown = [`# 📊 Acciones recientes de ${emailActual}\n`];
  registros.slice(-5).forEach(r => {
    markdown.push(`- ${r.timestamp} — ${r.action}`);
  });

  fs.writeFileSync(exportPath, markdown.join('\n'));
  console.log('\n✅ Exportado a cockpit/dashboard.md');
}

module.exports = mostrarDashboard;
