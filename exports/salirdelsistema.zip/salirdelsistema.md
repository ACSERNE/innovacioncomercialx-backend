# 🚪 Salir del sistema

Este micrositio representa la acción **🚪 Salir del sistema** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 🚪 Salir del sistema
```
