# ComercialX Cockpit — 🚪 Salir del sistema

Este paquete contiene los artefactos técnicos para la acción **🚪 Salir del sistema**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
