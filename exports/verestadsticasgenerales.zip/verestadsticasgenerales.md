# 📈 Ver estadísticas generales

Este micrositio representa la acción **📈 Ver estadísticas generales** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 📈 Ver estadísticas generales
```
