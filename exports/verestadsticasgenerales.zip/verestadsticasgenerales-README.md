# ComercialX Cockpit — 📈 Ver estadísticas generales

Este paquete contiene los artefactos técnicos para la acción **📈 Ver estadísticas generales**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
