# ComercialX Cockpit — 📊 Ver reportes filtrados

Este paquete contiene los artefactos técnicos para la acción **📊 Ver reportes filtrados**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
