# ComercialX Cockpit — ✏️ Editar producto existente

Este paquete contiene los artefactos técnicos para la acción **✏️ Editar producto existente**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
