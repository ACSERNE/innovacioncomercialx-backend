# ComercialX Cockpit — 🔐 Ver firma local de sesión

Este paquete contiene los artefactos técnicos para la acción **🔐 Ver firma local de sesión**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
