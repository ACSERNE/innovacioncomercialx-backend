# 🔐 Ver firma local de sesión

Este micrositio representa la acción **🔐 Ver firma local de sesión** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 🔐 Ver firma local de sesión
```
