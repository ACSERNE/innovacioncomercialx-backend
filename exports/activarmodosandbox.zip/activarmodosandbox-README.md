# ComercialX Cockpit — 🧪 Activar modo sandbox

Este paquete contiene los artefactos técnicos para la acción **🧪 Activar modo sandbox**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
