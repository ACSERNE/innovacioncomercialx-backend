# ComercialX Cockpit — 📦 Ver stock por producto

Este paquete contiene los artefactos técnicos para la acción **📦 Ver stock por producto**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
