# ComercialX Cockpit — 🔄 Iniciar sesión

Este paquete contiene los artefactos técnicos para la acción **🔄 Iniciar sesión**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
