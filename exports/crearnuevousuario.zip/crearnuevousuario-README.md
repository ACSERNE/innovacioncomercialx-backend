# ComercialX Cockpit — 🧑‍💼 Crear nuevo usuario

Este paquete contiene los artefactos técnicos para la acción **🧑‍💼 Crear nuevo usuario**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
