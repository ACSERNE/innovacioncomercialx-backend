# 🧑‍💼 Crear nuevo usuario

Este micrositio representa la acción **🧑‍💼 Crear nuevo usuario** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 🧑‍💼 Crear nuevo usuario
```
