# ComercialX Cockpit — 📈 Ejecutar plugin Analytics

Este paquete contiene los artefactos técnicos para la acción **📈 Ejecutar plugin Analytics**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
