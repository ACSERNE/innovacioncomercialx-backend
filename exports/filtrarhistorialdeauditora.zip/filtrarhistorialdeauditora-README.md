# ComercialX Cockpit — 🧾 Filtrar historial de auditoría

Este paquete contiene los artefactos técnicos para la acción **🧾 Filtrar historial de auditoría**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
