# ComercialX Cockpit — 🆕 Crear nuevo producto

Este paquete contiene los artefactos técnicos para la acción **🆕 Crear nuevo producto**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
