# 🆕 Crear nuevo producto

Este micrositio representa la acción **🆕 Crear nuevo producto** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 🆕 Crear nuevo producto
```
