# 🤖 Copilot CLI integrado

Este micrositio representa la acción **🤖 Copilot CLI integrado** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 🤖 Copilot CLI integrado
```
