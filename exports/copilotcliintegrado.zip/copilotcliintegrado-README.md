# ComercialX Cockpit — 🤖 Copilot CLI integrado

Este paquete contiene los artefactos técnicos para la acción **🤖 Copilot CLI integrado**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
