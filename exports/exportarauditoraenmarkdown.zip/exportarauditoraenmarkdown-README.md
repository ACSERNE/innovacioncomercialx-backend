# ComercialX Cockpit — 📝 Exportar auditoría en Markdown

Este paquete contiene los artefactos técnicos para la acción **📝 Exportar auditoría en Markdown**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
