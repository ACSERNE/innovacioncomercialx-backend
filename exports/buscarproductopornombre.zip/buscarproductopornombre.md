# 🔍 Buscar producto por nombre

Este micrositio representa la acción **🔍 Buscar producto por nombre** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 🔍 Buscar producto por nombre
```
