# 💰 Flujo de caja

Este micrositio representa la acción **💰 Flujo de caja** dentro del CLI ComercialX Cockpit.

## Artefactos generados

- HTML visual
- JSON técnico
- YAML estructurado
- Badge SVG
- ZIP exportable

## Uso CLI

```bash
node main.js
# Selecciona: 💰 Flujo de caja
```
