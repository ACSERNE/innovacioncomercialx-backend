# ComercialX Cockpit — 💰 Flujo de caja

Este paquete contiene los artefactos técnicos para la acción **💰 Flujo de caja**:

- Micrositio HTML
- Documentación Markdown
- Exportación JSON/YAML
- Badge SVG
- ZIP técnico

Publicado desde CLI cockpitizado.
