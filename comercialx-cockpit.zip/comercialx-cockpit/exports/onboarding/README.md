# 📘 ComercialX Cockpit | Onboarding Técnico

Este micrositio permite activar onboarding por tipo de tienda:

- 🏪 Tienda Física → $69.990
- 🛒 Tienda Online → $59.990
- 🔀 Híbrida → $89.990
- 🎁 Demo Técnica → Gratis

Incluye log técnico, exportación CSV y badge SVG por entorno.
