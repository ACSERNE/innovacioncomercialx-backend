# Auditoría Docker

**Estado:** validado
**Timestamp:** 2025-08-15T03:54:02.384Z

## Contenedores
- backend-innovacion (Restarting (1) 58 seconds ago)
- pgadmin-innovacion (Up 2 hours)
- backend-postgres-1 (Up 2 hours (healthy))